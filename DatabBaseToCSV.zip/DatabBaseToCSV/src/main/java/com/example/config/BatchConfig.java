package com.example.config;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import com.example.mapper.StudentMapper;
import com.example.model.Student;

@Configuration
public class BatchConfig {

@Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private StudentMapper studentMapper;

    @Autowired
    private DataSource dataSource;

    @Bean(name = "generateCSVReportCard")
    public Job generateCSVReportCard() {
        return jobBuilderFactory
                .get("generateReportCard")
                .incrementer(new RunIdIncrementer())
                .start(processStudentReport()).build();
    }

    @Bean
    public Step processStudentReport() {
        return stepBuilderFactory.get("processStudentReport")
                .<Student,Student>chunk(1)
                .reader(jdbcCursorItemReader())
                .writer(flatFileItemWriter())
                .build();
    }

    @Bean
    public JdbcCursorItemReader<Student> jdbcCursorItemReader(){
        JdbcCursorItemReader<Student> jdbcCursorItemReader
                = new JdbcCursorItemReader<>();
        jdbcCursorItemReader.setDataSource(dataSource);
        jdbcCursorItemReader.setSql("SELECT * FROM student");
        jdbcCursorItemReader.setRowMapper(studentMapper);
        return jdbcCursorItemReader;
    }

    @Bean
    public FlatFileItemWriter<Student> flatFileItemWriter(){
        FlatFileItemWriter<Student> flatFileItemWriter
                = new FlatFileItemWriter<>();
        flatFileItemWriter.setResource
          (new FileSystemResource	 
          ("C:\\Users\\ketan.naphade\\Desktop\\Spring-Batch\\student.csv"));
        flatFileItemWriter.setLineAggregator
           (new DelimitedLineAggregator<Student>() 
           {{
             setDelimiter(",");
             setFieldExtractor(
             	new BeanWrapperFieldExtractor<Student>() 
             {{
             	setNames(new String[]
              	{ "id", "name","percentage"});
             }});
            }});
        flatFileItemWriter.setHeaderCallback
                (writer -> writer.write("Id,Name,Percentage"));
        return flatFileItemWriter;
    }
}
